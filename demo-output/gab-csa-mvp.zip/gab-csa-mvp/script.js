// Accessibility and UI Enhancement Script
document.addEventListener('DOMContentLoaded', () => {
    // Handle preloader
    const preloader = document.getElementById('preloader');
    
    setTimeout(() => {
        preloader.classList.add('hidden');
    }, 800);
    
    const navLinks = document.querySelectorAll('nav a, .mobile-menu a');
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    const themeSwitch = document.getElementById('theme-switch');
    
    // Check for saved theme preference or prefer-color-scheme
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    const savedTheme = localStorage.getItem('theme');
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDarkScheme.matches)) {
        document.body.classList.add('dark-theme');
        themeSwitch.checked = true;
    }
    
    // Mobile menu toggle with improved accessibility
    mobileMenuToggle.addEventListener('click', () => {
        const isExpanded = mobileMenuToggle.getAttribute('aria-expanded') === 'true';
        mobileMenuToggle.setAttribute('aria-expanded', !isExpanded);
        mobileMenu.classList.toggle('active');
        mobileMenu.setAttribute('aria-hidden', isExpanded);
        
        // If opening the menu, shift focus to the first menu item
        if (!isExpanded) {
            const firstMenuItem = mobileMenu.querySelector('a');
            if (firstMenuItem) {
                setTimeout(() => {
                    firstMenuItem.focus();
                }, 100);
            }
        }
    });
    
    // Handle Escape key press to close mobile menu
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobileMenu.classList.contains('active')) {
            mobileMenuToggle.click();
            mobileMenuToggle.focus(); // Return focus to the toggle button
        }
    });
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Remove active class from all links
            navLinks.forEach(link => link.classList.remove('active'));
            navLinks.forEach(link => link.removeAttribute('aria-current'));
            
            // Add active class to clicked link
            this.classList.add('active');
            this.setAttribute('aria-current', 'page');
            
            // Close mobile menu when a link is clicked
            if (mobileMenu.classList.contains('active')) {
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
                mobileMenu.classList.remove('active');
                mobileMenu.setAttribute('aria-hidden', 'true');
            }
            
            // If it's a hash link, handle smooth scrolling
            if (this.getAttribute('href').startsWith('#') && this.getAttribute('href') !== '#') {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Set focus to the target section for better accessibility
                    targetElement.setAttribute('tabindex', '-1');
                    targetElement.focus({ preventScroll: true });
                    
                    // Update URL without causing a page jump
                    history.pushState(null, null, targetId);
                }
            }
        });
    });

    // Sticky header behavior
    const header = document.querySelector('header');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > 100) {
            header.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
            header.style.background = getComputedStyle(document.body).getPropertyValue('--header-background-scroll') || 'rgba(255, 255, 255, 0.98)';
        } else {
            header.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.05)';
            header.style.background = getComputedStyle(document.body).getPropertyValue('--header-background') || 'var(--white)';
        }
        
        lastScrollTop = scrollTop;
    });
    
    // Add animation for feature cards on scroll with ARIA updates
    const featureCards = document.querySelectorAll('.feature-card');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });
    
    featureCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(card);
        
        // Add keyboard event handling for feature cards
        card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                card.click();
            }
        });
    });
    
    // Add animation for CTA section
    const ctaSection = document.querySelector('.cta-section');
    if (ctaSection) {
        ctaSection.style.opacity = '0';
        ctaSection.style.transform = 'translateY(20px)';
        ctaSection.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(ctaSection);
    }
    
    // Handle theme toggle with accessibility improvements
    themeSwitch.addEventListener('change', () => {
        if (themeSwitch.checked) {
            document.body.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark');
            // Announce theme change to screen readers
            announceToScreenReader("Dark theme enabled");
        } else {
            document.body.classList.remove('dark-theme');
            localStorage.setItem('theme', 'light');
            // Announce theme change to screen readers
            announceToScreenReader("Light theme enabled");
        }
    });
    
    // Helper function to announce messages to screen readers
    function announceToScreenReader(message) {
        const announcer = document.createElement('div');
        announcer.setAttribute('aria-live', 'polite');
        announcer.setAttribute('aria-atomic', 'true');
        announcer.classList.add('sr-only');
        document.body.appendChild(announcer);
        
        setTimeout(() => {
            announcer.textContent = message;
            
            // Clean up after announcement
            setTimeout(() => {
                document.body.removeChild(announcer);
            }, 1000);
        }, 100);
    }
    
    // Scroll to top functionality with keyboard support
    const scrollToTopBtn = document.getElementById('scroll-to-top');
    
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
            scrollToTopBtn.setAttribute('aria-hidden', 'false');
        } else {
            scrollToTopBtn.classList.remove('visible');
            scrollToTopBtn.setAttribute('aria-hidden', 'true');
        }
    });
    
    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
        
        // Focus the top of the page or the first focusable element
        setTimeout(() => {
            const firstFocusable = document.querySelector('header a, header button');
            if (firstFocusable) firstFocusable.focus();
        }, 500);
    });
    
    // Feature card modal functionality with focus management
    const modalFeatureCards = document.querySelectorAll('.feature-card[data-modal]');
    const featureModals = document.querySelectorAll('.feature-modal-overlay');
    const modalCloseBtns = document.querySelectorAll('.feature-modal-close, .modal-close-btn');
    
    // Keep track of the element that had focus before opening a modal
    let lastFocusedElementBeforeModal;
    
    modalFeatureCards.forEach(card => {
        card.addEventListener('click', () => {
            const modalId = card.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            if (modal) {
                // Save the last focused element before opening modal
                lastFocusedElementBeforeModal = document.activeElement;
                
                // Show modal and set appropriate ARIA attributes
                modal.classList.add('active');
                modal.setAttribute('aria-hidden', 'false');
                document.body.style.overflow = 'hidden'; // Prevent scrolling
                
                // Update ARIA attribute on the card
                card.setAttribute('aria-expanded', 'true');
                
                // Focus the first focusable element in the modal
                const firstFocusable = modal.querySelector('button, [tabindex]:not([tabindex="-1"])');
                if (firstFocusable) {
                    setTimeout(() => {
                        firstFocusable.focus();
                    }, 100);
                }
                
                // Set up focus trap within modal
                setupFocusTrap(modal);
            }
        });
    });
    
    function setupFocusTrap(modal) {
        const focusableElements = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];
        
        modal.addEventListener('keydown', trapFocus);
        
        function trapFocus(e) {
            if (e.key === 'Tab') {
                if (e.shiftKey && document.activeElement === firstFocusable) {
                    e.preventDefault();
                    lastFocusable.focus();
                } else if (!e.shiftKey && document.activeElement === lastFocusable) {
                    e.preventDefault();
                    firstFocusable.focus();
                }
            }
        }
    }
    
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = ''; // Restore scrolling
            
            // Update ARIA attribute on the triggering card
            const cardId = modal.id;
            const card = document.querySelector(`.feature-card[data-modal="${cardId}"]`);
            if (card) {
                card.setAttribute('aria-expanded', 'false');
            }
            
            // Return focus to the element that had focus before the modal was opened
            if (lastFocusedElementBeforeModal) {
                lastFocusedElementBeforeModal.focus();
            }
            
            // Remove event listener for focus trap
            modal.removeEventListener('keydown', function() {});
        }
    }
    
    modalCloseBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.feature-modal-overlay');
            closeModal(modal);
        });
    });
    
    // Close modal when clicking outside
    featureModals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            featureModals.forEach(modal => {
                if (modal.classList.contains('active')) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Form validation for subscription with improved accessibility
    const subscribeForm = document.getElementById('subscribe-form');
    const emailInput = document.getElementById('email-input');
    const formFeedback = document.getElementById('form-feedback');
    
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Simple email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const email = emailInput.value.trim();
            
            if (!emailRegex.test(email)) {
                emailInput.classList.add('error');
                emailInput.setAttribute('aria-invalid', 'true');
                formFeedback.textContent = 'Please enter a valid email address';
                formFeedback.classList.add('error');
                
                // Announce error to screen readers
                formFeedback.setAttribute('role', 'alert');
                
                setTimeout(() => {
                    emailInput.classList.remove('error');
                }, 500);
                
                return;
            }
            
            // Simulating form submission
            emailInput.disabled = true;
            emailInput.setAttribute('aria-invalid', 'false');
            formFeedback.textContent = 'Subscribing...';
            formFeedback.classList.remove('error');
            
            setTimeout(() => {
                formFeedback.innerHTML = '<div class="subscribe-success"><div class="success-checkmark"></div>Successfully subscribed!</div>';
                formFeedback.classList.add('success');
                
                // Reset form after 3 seconds
                setTimeout(() => {
                    subscribeForm.reset();
                    emailInput.disabled = false;
                    formFeedback.textContent = '';
                    formFeedback.classList.remove('success');
                }, 3000);
            }, 1500);
        });
        
        // Remove error state when user starts typing again
        emailInput.addEventListener('input', () => {
            formFeedback.textContent = '';
            formFeedback.classList.remove('error');
            emailInput.setAttribute('aria-invalid', 'false');
        });
    }
});
