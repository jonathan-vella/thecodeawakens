# Azure resources configuration
@{
    # Enable or disable specific rules by name
    Rule = @{
        # Exclude a rule by name
        # 'Azure.Resource.UseTags' = 'off'
    }

    # Configure rule defaults
    Configuration = @{
        # Set the default minimum number of availability zones
        'Azure.VM.UseAvailabilityZone' = @{
            'minZones' = 2
        }

        # Set default allowed Azure regions
        'Azure.Resource.AllowedRegions' = @{
            'AllowedRegions' = @('eastus', 'eastus2', 'westus2', 'northeurope', 'westeurope')
        }
    }
}