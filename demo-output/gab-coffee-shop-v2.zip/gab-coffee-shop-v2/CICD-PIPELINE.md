# Azure Infrastructure CI/CD Pipeline

This document provides information about the GitHub CI/CD pipeline for the Coffee Ordering application deployment to Azure.

## Pipeline Overview

The pipeline automates the deployment of Azure infrastructure using Bicep templates and follows a structured approach:

1. **Validation Stage**: Validates Bicep templates for syntax errors and deployment issues
2. **Preview Stage**: Generates a preview of changes using Azure's What-If analysis
3. **Deployment Stage**: Deploys resources to the specified environment

The pipeline supports three environments: `dev`, `test`, and `prod`, and can be triggered by:
- Pushing changes to Bicep files on the main branch
- Opening a pull request with Bicep file changes
- Manually running the workflow through GitHub UI

## Pipeline Flow

```mermaid
flowchart TD
    A[Push Code / PR / Manual Trigger] --> B[Validate]
    B --> C{Validation Passed?}
    C -->|No| D[Pipeline Fails]
    C -->|Yes| E[Preview Changes]
    E --> F{Manual Trigger or Push to Main?}
    F -->|No| G[Pipeline Ends]
    F -->|Yes| H[Deploy Resources]
    H --> I[Run Post-Deployment Tests]
    I --> J[Deployment Complete]
```

## Authentication & Security

The pipeline uses OpenID Connect (OIDC) for secure authentication to Azure, avoiding long-lived credentials:

- Uses GitHub's OIDC provider for Azure authentication
- Requires Azure service principal with appropriate RBAC permissions
- Stores sensitive information in GitHub Secrets

## Setup Instructions

### 1. Configure Azure Prerequisites

Create a service principal with contributor access to your subscription:

```bash
# Login to Azure
az login

# Create service principal with Contributor role
az ad sp create-for-rbac --name "GithubActionsCoffeeApp" --role contributor \
                          --scopes /subscriptions/{subscription-id} \
                          --sdk-auth
```

Save the output JSON - you'll need the values for GitHub secrets.

### 2. Configure GitHub Secrets

Add the following secrets to your GitHub repository:

- `AZURE_CLIENT_ID`: The client ID from the service principal
- `AZURE_TENANT_ID`: Your Azure tenant ID
- `AZURE_SUBSCRIPTION_ID`: Your Azure subscription ID
- `SQL_ADMIN_USERNAME`: SQL Server administrator username
- `SQL_ADMIN_PASSWORD`: SQL Server administrator password

### 3. Configure GitHub Environments (Optional)

For better separation of deployments, create GitHub environments:

1. Go to your repository settings → Environments
2. Create environments for `dev`, `test`, and `prod`
3. Add protection rules like required reviewers for production deployments

### 4. Customize the Workflow

You may need to update:

- `PROJECT_NAME` environment variable in the workflow file
- `LOCATION` environment variable to match your preferred Azure region
- Path filters if you reorganize your Bicep files

## Usage

### Automatic Deployments

The pipeline automatically runs when:
- Pushing Bicep file changes to the main branch
- Opening a pull request with Bicep file changes

### Manual Deployments

To trigger a manual deployment:

1. Go to Actions tab in your repository
2. Select the "Deploy Azure Infrastructure" workflow
3. Click "Run workflow"
4. Select the target environment (dev, test, prod)
5. Click "Run workflow"

## Monitoring Deployments

Monitor deployments through:
- GitHub Actions tab in your repository
- Azure Portal → Resource Group → Deployments blade

## Troubleshooting

Common issues and solutions:

1. **Authentication Failures**: Verify your service principal has valid permissions and secrets are correctly configured.
2. **Deployment Failures**: Check the Azure deployment logs in GitHub Actions output and Azure Portal.
3. **Parameter Issues**: Ensure all required parameters are provided in the workflow file and secrets are available.

## Resources

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Azure Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure CLI Documentation](https://learn.microsoft.com/en-us/cli/azure/)