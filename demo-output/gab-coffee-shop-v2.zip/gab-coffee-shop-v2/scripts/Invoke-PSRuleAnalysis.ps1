<#
.SYNOPSIS
    Validates Bicep files against Azure best practices using PSRule for Azure.
.DESCRIPTION
    This script analyzes Bicep files in the current directory against PSRule for Azure rules.
    Results are displayed in the console and can optionally be exported to HTML or other formats.
.EXAMPLE
    .\Invoke-PSRuleAnalysis.ps1
    Runs analysis on all Bicep files in the current directory and subdirectories.
.EXAMPLE
    .\Invoke-PSRuleAnalysis.ps1 -OutputPath "C:\Reports" -OutputFormat Html
    Runs analysis and saves results to HTML in the specified output path.
.NOTES
    Requires PSRule.Rules.Azure PowerShell module.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [ValidateSet('Detail', 'Summary')]
    [string]$As = 'Detail',

    [Parameter(Mandatory = $false)]
    [ValidateSet('Yaml', 'Json', 'Markdown', 'NUnit3', 'Csv', 'Sarif', 'Html')]
    [string]$OutputFormat = 'Detail',

    [Parameter(Mandatory = $false)]
    [string]$OutputPath,

    [Parameter(Mandatory = $false)]
    [string]$Path = (Get-Location)
)

# Ensure required modules are installed
function EnsureModuleInstalled {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ModuleName
    )

    if (-not (Get-Module -Name $ModuleName -ListAvailable)) {
        Write-Host "Installing $ModuleName module..."
        Install-Module -Name $ModuleName -Scope CurrentUser -Force
        Write-Host "$ModuleName module installed successfully." -ForegroundColor Green
    }
    else {
        Write-Host "$ModuleName module is already installed." -ForegroundColor Green
    }
}

# Main execution
try {
    # Check and install required modules
    EnsureModuleInstalled -ModuleName 'PSRule.Rules.Azure'
    EnsureModuleInstalled -ModuleName 'Az.Resources'

    # Display module version
    Write-Host "PSRule.Rules.Azure module version:" -ForegroundColor Cyan
    Get-Module -Name 'PSRule.Rules.Azure' -ListAvailable | Format-Table -Property Version, Name, Path

    # Prepare output parameters
    $params = @{
        Module = 'PSRule.Rules.Azure'
        As = $As
        Format = $OutputFormat
    }

    # Add output path if specified
    if ($OutputPath) {
        if (!(Test-Path -Path $OutputPath)) {
            New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
            Write-Host "Created output directory: $OutputPath" -ForegroundColor Yellow
        }
        $params['OutputPath'] = $OutputPath
    }

    # Run analysis on Bicep files
    Write-Host "Analyzing Bicep files in $Path..." -ForegroundColor Cyan
    $bicepFiles = Get-ChildItem -Path $Path -Filter '*.bicep' -Recurse
    
    if ($bicepFiles.Count -eq 0) {
        Write-Warning "No Bicep files found in the specified path."
        return
    }
    
    Write-Host "Found $($bicepFiles.Count) Bicep files to analyze." -ForegroundColor Yellow
    
    # Execute PSRule
    $results = $bicepFiles | Assert-PSRule @params
    
    # Display summary
    $failedCount = ($results | Where-Object { $_.Outcome -eq 'Fail' }).Count
    $passedCount = ($results | Where-Object { $_.Outcome -eq 'Pass' }).Count
    
    Write-Host "`nSummary:" -ForegroundColor Cyan
    Write-Host "- Passed: $passedCount" -ForegroundColor Green
    Write-Host "- Failed: $failedCount" -ForegroundColor ($failedCount -gt 0 ? 'Red' : 'Green')
    
    if ($failedCount -gt 0) {
        Write-Host "`nFailed rules:" -ForegroundColor Red
        $results | Where-Object { $_.Outcome -eq 'Fail' } | Format-Table -Property RuleName, TargetName -AutoSize
    }
    
    if ($OutputPath) {
        Write-Host "`nResults saved to: $OutputPath" -ForegroundColor Yellow
    }
}
catch {
    Write-Error "An error occurred during PSRule analysis: $_"
}
finally {
    Write-Host "`nPSRule analysis completed." -ForegroundColor Cyan
}