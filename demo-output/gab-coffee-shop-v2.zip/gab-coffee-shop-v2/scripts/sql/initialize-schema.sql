-- Initialize Coffee Order Database Schema

-- Customer table to store user information
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Customers')
BEGIN
    CREATE TABLE Customers (
        CustomerId INT IDENTITY(1,1) PRIMARY KEY,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        FirstName NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        Email NVARCHAR(100) NOT NULL UNIQUE,
        PreferredDeliveryAddress NVARCHAR(500) NULL,
        MarketingPreference BIT NOT NULL DEFAULT 0, -- 0 = Opt-out, 1 = Opt-in
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedDate DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    PRINT 'Customers table created.';
END
ELSE
BEGIN
    PRINT 'Customers table already exists.';
END

-- Products table to store coffee products
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Products')
BEGIN
    CREATE TABLE Products (
        ProductId INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        Price DECIMAL(10, 2) NOT NULL,
        ImageUrl NVARCHAR(255) NULL,
        IsAvailable BIT NOT NULL DEFAULT 1,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedDate DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    PRINT 'Products table created.';
END
ELSE
BEGIN
    PRINT 'Products table already exists.';
END

-- Orders table to store coffee orders
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Orders')
BEGIN
    CREATE TABLE Orders (
        OrderId INT IDENTITY(1,1) PRIMARY KEY,
        CustomerId INT NOT NULL,
        OrderDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        TotalAmount DECIMAL(10, 2) NOT NULL,
        Status NVARCHAR(20) NOT NULL, -- Pending, Processing, Delivered, Cancelled
        DeliveryAddress NVARCHAR(500) NOT NULL,
        CONSTRAINT FK_Orders_Customers FOREIGN KEY (CustomerId) REFERENCES Customers(CustomerId)
    );
    
    PRINT 'Orders table created.';
END
ELSE
BEGIN
    PRINT 'Orders table already exists.';
END

-- OrderItems table to store individual items in an order
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderItems')
BEGIN
    CREATE TABLE OrderItems (
        OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
        OrderId INT NOT NULL,
        ProductId INT NOT NULL,
        Quantity INT NOT NULL,
        UnitPrice DECIMAL(10, 2) NOT NULL,
        Subtotal DECIMAL(10, 2) NOT NULL,
        CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId) REFERENCES Orders(OrderId),
        CONSTRAINT FK_OrderItems_Products FOREIGN KEY (ProductId) REFERENCES Products(ProductId)
    );
    
    PRINT 'OrderItems table created.';
END
ELSE
BEGIN
    PRINT 'OrderItems table already exists.';
END

-- Insert sample coffee products if Products table is empty
IF NOT EXISTS (SELECT TOP 1 * FROM Products)
BEGIN
    INSERT INTO Products (Name, Description, Price, ImageUrl, IsAvailable)
    VALUES 
    ('Light Roast Coffee', 'A smooth, mild-bodied coffee with bright acidity.', 12.99, '/images/light-roast.jpg', 1),
    ('Medium Roast Coffee', 'A balanced, medium-bodied coffee with a rich flavor.', 14.99, '/images/medium-roast.jpg', 1),
    ('Dark Roast Coffee', 'A full-bodied coffee with deep, rich flavors.', 16.99, '/images/dark-roast.jpg', 1),
    ('Espresso Blend', 'A rich, intense blend perfect for espresso machines.', 18.99, '/images/espresso.jpg', 1),
    ('Custom Blend', 'Our signature house blend with notes of chocolate and caramel.', 19.99, '/images/custom-blends.jpg', 1);
    
    PRINT 'Sample products inserted.';
END
ELSE
BEGIN
    PRINT 'Products table already has data.';
END

PRINT 'Database initialization completed.';