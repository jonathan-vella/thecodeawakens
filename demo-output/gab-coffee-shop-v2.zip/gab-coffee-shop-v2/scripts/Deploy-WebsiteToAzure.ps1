param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory = $true)]
    [string]$WebAppName,
    
    [Parameter(Mandatory = $false)]
    [string]$WebsiteRoot = ".\wwwroot"
)

# Ensure Azure is logged in
$loginStatus = az account show --query name -o tsv 2>$null
if (-not $loginStatus) {
    Write-Host "Logging into Azure..."
    az login
}

# Check if web app exists
Write-Host "Checking if web app $WebAppName exists in resource group $ResourceGroupName..."
$webApp = az webapp show --name $WebAppName --resource-group $ResourceGroupName 2>$null

if (-not $webApp) {
    Write-Host "Web app not found. Please make sure the web app exists before deploying content." -ForegroundColor Red
    exit 1
}

# Create placeholder images if they don't exist
$imageDir = Join-Path $WebsiteRoot "images"
if (-not (Test-Path $imageDir)) {
    New-Item -Path $imageDir -ItemType Directory -Force | Out-Null
}

# List of image files needed
$imageFiles = @(
    "brew-bliss-logo.png", 
    "hero-coffee.jpg", 
    "fresh-roasted.jpg", 
    "custom-blends.jpg", 
    "quick-delivery.jpg", 
    "light-roast.jpg", 
    "medium-roast.jpg", 
    "dark-roast.jpg", 
    "espresso.jpg",
    "icon-facebook.svg",
    "icon-instagram.svg",
    "icon-twitter.svg"
)

# Create placeholder images
foreach ($image in $imageFiles) {
    $imagePath = Join-Path $imageDir $image
    
    if (-not (Test-Path $imagePath)) {
        Write-Host "Creating placeholder for $image..." -ForegroundColor Yellow
        
        # For SVG files
        if ($image.EndsWith(".svg")) {
            $svgContent = @"
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <circle cx="12" cy="12" r="10" fill="#6f4e37" />
  <text x="12" y="16" font-family="Arial" font-size="8" text-anchor="middle" fill="white">
    $($image.Replace(".svg", ""))
  </text>
</svg>
"@
            Set-Content -Path $imagePath -Value $svgContent
        } 
        # For PNG or JPG files
        else {
            # Create a colored placeholder rectangle using .NET
            Add-Type -AssemblyName System.Drawing
            $width = 400
            $height = 300
            $bmp = New-Object System.Drawing.Bitmap $width, $height
            $graphics = [System.Drawing.Graphics]::FromImage($bmp)
            
            # Fill background
            $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(111, 78, 55)) # Coffee brown
            $graphics.FillRectangle($brush, 0, 0, $width, $height)
            
            # Add text
            $font = New-Object System.Drawing.Font("Arial", 20)
            $textBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
            $textFormat = New-Object System.Drawing.StringFormat
            $textFormat.Alignment = [System.Drawing.StringAlignment]::Center
            $textFormat.LineAlignment = [System.Drawing.StringAlignment]::Center
            $text = $image.Replace(".jpg", "").Replace(".png", "")
            
            # Fixed the DrawString method call - it was missing proper parameters
            $rect = New-Object System.Drawing.RectangleF(0, 0, $width, $height)
            $graphics.DrawString($text, $font, $textBrush, $rect, $textFormat)
            
            # Save the image
            $imageFormat = if ($image.EndsWith(".jpg")) {
                [System.Drawing.Imaging.ImageFormat]::Jpeg
            } else {
                [System.Drawing.Imaging.ImageFormat]::Png
            }
            $bmp.Save($imagePath, $imageFormat)
            
            # Clean up
            $graphics.Dispose()
            $bmp.Dispose()
        }
    }
}

# Zip the website content
$zipPath = ".\website.zip"
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

Write-Host "Compressing website content..."
Compress-Archive -Path "$WebsiteRoot\*" -DestinationPath $zipPath -Force

# Deploy the website to the web app
Write-Host "Deploying website to $WebAppName..."
az webapp deployment source config-zip --resource-group $ResourceGroupName --name $WebAppName --src $zipPath

# Clean up
Write-Host "Cleaning up temporary files..."
Remove-Item $zipPath -Force

Write-Host "Deployment completed successfully!" -ForegroundColor Green
Write-Host "Your website should be accessible at: https://$WebAppName.azurewebsites.net"