# Script to grant Key Vault access permissions
param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory = $true)]
    [string]$KeyVaultName,
    
    [Parameter(Mandatory = $false)]
    [string]$ObjectId = "2dcbd005-a02f-49c9-b5fb-5c03d4f6e28a" # Default to the ObjectId from the error message
)

Write-Host "Granting Key Vault access permissions..." -ForegroundColor Cyan

# Ensure Azure is logged in
$loginStatus = az account show --query name -o tsv 2>$null
if (-not $loginStatus) {
    Write-Host "Logging into Azure..." -ForegroundColor Yellow
    az login
}

# Check if Key Vault exists
Write-Host "Checking if Key Vault $KeyVaultName exists in resource group $ResourceGroupName..." -ForegroundColor Yellow
$keyVault = az keyvault show --name $KeyVaultName --resource-group $ResourceGroupName 2>$null

if (-not $keyVault) {
    Write-Host "Key Vault not found. Please make sure the Key Vault exists before setting permissions." -ForegroundColor Red
    exit 1
}

try {
    # Get current user's Object ID if none was provided
    if (-not $ObjectId) {
        Write-Host "No ObjectId provided, getting current user's ObjectId..." -ForegroundColor Yellow
        $currentUser = az ad signed-in-user show --query id -o tsv
        if ($currentUser) {
            $ObjectId = $currentUser
            Write-Host "Using current user's ObjectId: $ObjectId" -ForegroundColor Yellow
        } else {
            Write-Host "Could not get current user's ObjectId. Please provide an ObjectId." -ForegroundColor Red
            exit 1
        }
    }

    # Grant Secret Management permissions to the Object ID
    Write-Host "Granting Secret Management permissions to ObjectId $ObjectId..." -ForegroundColor Yellow
    $result = az keyvault set-policy --name $KeyVaultName --resource-group $ResourceGroupName --object-id $ObjectId --secret-permissions get list set delete backup restore recover purge 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to set Key Vault policy: $result"
    }

    Write-Host "Successfully granted Key Vault permissions to ObjectId $ObjectId" -ForegroundColor Green
}
catch {
    Write-Host "Error setting Key Vault permissions: $_" -ForegroundColor Red
    exit 1
}

# Create and set the needed SQL admin secrets in Key Vault
try {
    Write-Host "Creating SQL admin credentials in Key Vault..." -ForegroundColor Yellow
    
    # Generate a random password if needed
    $sqlPassword = -join ((65..90) + (97..122) + (48..57) + (35..38) | Get-Random -Count 16 | ForEach-Object { [char]$_ })
    
    # Set the SQL admin username and password in Key Vault
    az keyvault secret set --vault-name $KeyVaultName --name "SqlAdminUsername" --value "sqladmin" | Out-Null
    az keyvault secret set --vault-name $KeyVaultName --name "SqlAdminPassword" --value $sqlPassword | Out-Null
    
    Write-Host "Successfully created SQL admin credentials in Key Vault." -ForegroundColor Green
}
catch {
    Write-Host "Error creating SQL admin credentials: $_" -ForegroundColor Red
    Write-Host "You may need to manually set these secrets in the Key Vault." -ForegroundColor Yellow
}

# Skip the service principal that couldn't be found
Write-Host "The service principal with AppId 04b07795-8ddb-461a-bbee-02f9e1bf7b46 could not be found." -ForegroundColor Yellow
Write-Host "This is typically the Azure CLI service principal and may be from a different tenant." -ForegroundColor Yellow
Write-Host "We've already granted your account access to the Key Vault, which should be sufficient." -ForegroundColor Yellow

Write-Host "Key Vault access permission setup complete." -ForegroundColor Green
Write-Host "Try running your original command again, or add SQL secrets manually if needed." -ForegroundColor Green