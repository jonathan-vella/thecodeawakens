# Script to initialize the SQL database schema
param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory = $true)]
    [string]$KeyVaultName,
    
    [Parameter(Mandatory = $true)]
    [string]$SqlServerName,
    
    [Parameter(Mandatory = $true)]
    [string]$DatabaseName,
    
    [Parameter(Mandatory = $false)]
    [string]$SchemaScriptPath = "$PSScriptRoot\sql\initialize-schema.sql"
)

Write-Host "Initializing database schema for coffee ordering database..." -ForegroundColor Cyan

# Ensure Azure is logged in
$loginStatus = az account show --query name -o tsv 2>$null
if (-not $loginStatus) {
    Write-Host "Logging into Azure..." -ForegroundColor Yellow
    az login
}

# Check if the SQL script exists
if (-not (Test-Path $SchemaScriptPath)) {
    Write-Host "Error: Schema script not found at path: $SchemaScriptPath" -ForegroundColor Red
    exit 1
}

# Get SQL admin username and password from Key Vault
try {
    Write-Host "Retrieving SQL credentials from KeyVault..." -ForegroundColor Yellow
    $sqlUsername = az keyvault secret show --vault-name $KeyVaultName --name "SqlAdminUsername" --query "value" -o tsv
    $sqlPassword = az keyvault secret show --vault-name $KeyVaultName --name "SqlAdminPassword" --query "value" -o tsv
    
    if (-not $sqlUsername -or -not $sqlPassword) {
        throw "Unable to retrieve SQL credentials from Key Vault"
    }
} 
catch {
    Write-Host "Error retrieving SQL credentials: $_" -ForegroundColor Red
    exit 1
}

# Get SQL Server FQDN
try {
    Write-Host "Getting SQL Server FQDN..." -ForegroundColor Yellow
    $sqlServerFqdn = az sql server show --name $SqlServerName --resource-group $ResourceGroupName --query "fullyQualifiedDomainName" -o tsv
    
    if (-not $sqlServerFqdn) {
        throw "Unable to get SQL Server FQDN"
    }
}
catch {
    Write-Host "Error retrieving SQL Server FQDN: $_" -ForegroundColor Red
    exit 1
}

# Execute SQL script using sqlcmd
try {
    Write-Host "Executing database schema initialization script..." -ForegroundColor Yellow
    
    # Check if sqlcmd is installed
    $sqlcmdExists = Get-Command sqlcmd -ErrorAction SilentlyContinue
    
    if (-not $sqlcmdExists) {
        Write-Host "sqlcmd is not installed. Please install SQL Server command-line tools to run this script." -ForegroundColor Red
        Write-Host "You can install it using: `nInvoke-WebRequest https://aka.ms/get-sqlcmd-windows -OutFile sqlcmd.msi; Start-Process -Wait msiexec -ArgumentList '/i sqlcmd.msi /qn'" -ForegroundColor Yellow
        exit 1
    }
    
    # Build connection string for sqlcmd
    $connectionParams = "-S tcp:$sqlServerFqdn,1433 -d $DatabaseName -U $sqlUsername -P $sqlPassword"
    
    # Execute sqlcmd with the schema script
    $output = Invoke-Expression "sqlcmd $connectionParams -i `"$SchemaScriptPath`" -o `"$PSScriptRoot\sql\output.log`""
    
    Write-Host "Database schema initialization completed successfully!" -ForegroundColor Green
    Write-Host "Check $PSScriptRoot\sql\output.log for details."
}
catch {
    Write-Host "Error executing SQL schema script: $_" -ForegroundColor Red
    exit 1
}

Write-Host "Database schema initialization complete." -ForegroundColor Green