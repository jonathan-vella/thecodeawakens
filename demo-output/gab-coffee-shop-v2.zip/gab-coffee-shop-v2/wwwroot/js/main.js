// Shopping Cart Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Cart state
    let cart = [];
    const shippingRate = 4.99;
    const taxRate = 0.07;
    
    // DOM Elements
    const cartItemsContainer = document.getElementById('cart-items');
    const subtotalElement = document.getElementById('subtotal-amount');
    const shippingElement = document.getElementById('shipping-amount');
    const totalElement = document.getElementById('total-amount');
    const checkoutButton = document.getElementById('checkout-button');
    const emptyCartMessage = document.querySelector('.empty-cart-message');
    
    // Add event listeners to all "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const price = parseFloat(this.getAttribute('data-price'));
            
            addItemToCart(id, name, price, 1);
            updateCartDisplay();
        });
    });
    
    // Add item to cart function
    function addItemToCart(id, name, price, quantity) {
        // Check if item is already in cart
        const existingItem = cart.find(item => item.id === id);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            cart.push({
                id: id,
                name: name,
                price: price,
                quantity: quantity
            });
        }
        
        // Save cart to localStorage for persistence
        saveCart();
    }
    
    // Update cart display
    function updateCartDisplay() {
        // Clear current display
        cartItemsContainer.innerHTML = '';
        
        if (cart.length === 0) {
            // Show empty cart message
            cartItemsContainer.appendChild(emptyCartMessage);
            checkoutButton.disabled = true;
            
            // Update summary
            updateOrderSummary(0);
            return;
        }
        
        // Hide empty cart message
        emptyCartMessage.remove();
        checkoutButton.disabled = false;
        
        // Calculate subtotal
        let subtotal = 0;
        
        // Add each item to display
        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            
            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item';
            
            cartItemElement.innerHTML = `
                <div class="cart-item-info">
                    <span>${item.name}</span>
                </div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn minus" data-id="${item.id}">-</button>
                    <span class="quantity-value">${item.quantity}</span>
                    <button class="quantity-btn plus" data-id="${item.id}">+</button>
                    <span class="item-price">$${(item.price * item.quantity).toFixed(2)}</span>
                    <button class="remove-item" data-id="${item.id}">×</button>
                </div>
            `;
            
            cartItemsContainer.appendChild(cartItemElement);
        });
        
        // Update order summary
        updateOrderSummary(subtotal);
        
        // Add event listeners to quantity buttons
        addQuantityButtonListeners();
    }
    
    // Update order summary
    function updateOrderSummary(subtotal) {
        const shipping = cart.length > 0 ? shippingRate : 0;
        const total = subtotal + shipping;
        
        subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
        shippingElement.textContent = `$${shipping.toFixed(2)}`;
        totalElement.textContent = `$${total.toFixed(2)}`;
    }
    
    // Add event listeners to quantity buttons
    function addQuantityButtonListeners() {
        // Plus buttons
        document.querySelectorAll('.quantity-btn.plus').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const item = cart.find(item => item.id === id);
                if (item) {
                    item.quantity += 1;
                    saveCart();
                    updateCartDisplay();
                }
            });
        });
        
        // Minus buttons
        document.querySelectorAll('.quantity-btn.minus').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const item = cart.find(item => item.id === id);
                if (item) {
                    item.quantity -= 1;
                    if (item.quantity <= 0) {
                        removeItemFromCart(id);
                    }
                    saveCart();
                    updateCartDisplay();
                }
            });
        });
        
        // Remove buttons
        document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                removeItemFromCart(id);
                saveCart();
                updateCartDisplay();
            });
        });
    }
    
    // Remove item from cart
    function removeItemFromCart(id) {
        cart = cart.filter(item => item.id !== id);
    }
    
    // Save cart to localStorage
    function saveCart() {
        localStorage.setItem('coffeeCart', JSON.stringify(cart));
    }
    
    // Load cart from localStorage
    function loadCart() {
        const savedCart = localStorage.getItem('coffeeCart');
        if (savedCart) {
            cart = JSON.parse(savedCart);
            updateCartDisplay();
        }
    }
    
    // Form validation
    const orderForm = document.getElementById('orderForm');
    if (orderForm) {
        orderForm.addEventListener('submit', function(event) {
            if (cart.length === 0) {
                event.preventDefault();
                alert('Your cart is empty. Please add items before checking out.');
            }
        });
    }
    
    // Initialize
    loadCart();
    
    // Newsletter form validation
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const email = document.getElementById('newsletterEmail').value;
            const consent = document.getElementById('newsletterConsent').checked;
            
            if (!email || !consent) {
                alert('Please fill in your email and consent to subscribe.');
                return;
            }
            
            // In a real app, you would submit this to your backend
            alert('Thank you for subscribing to our newsletter!');
            newsletterForm.reset();
        });
    }
    
    // Signup form validation
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match. Please try again.');
                return;
            }
            
            // In a real app, you would submit this to your backend
            alert('Account created successfully! You can now log in.');
            signupForm.reset();
        });
    }
});