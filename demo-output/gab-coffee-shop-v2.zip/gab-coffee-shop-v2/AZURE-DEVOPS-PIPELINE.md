# Azure DevOps CI/CD Pipeline

This document provides information about the Azure DevOps CI/CD pipeline for the Coffee Ordering application deployment to Azure.

## Pipeline Overview

The pipeline automates the deployment of Azure infrastructure using Bicep templates and follows a structured approach:

1. **Validation Stage**: Validates Bicep templates for syntax errors and deployment issues
2. **Preview Stage**: Generates a preview of changes using Azure's What-If analysis
3. **Deployment Stage**: Deploys resources to the specified environment
4. **Test Stage**: Runs post-deployment health checks

The pipeline supports three environments: `dev`, `test`, and `prod`, and can be triggered by:
- Pushing changes to Bicep files on the main branch
- Pull requests with Bicep file changes
- Weekly scheduled runs
- Manual triggers through the Azure DevOps UI

## Pipeline Flow

```mermaid
flowchart TD
    A[Trigger: Push/PR/Schedule/Manual] --> B[Validate Stage]
    B --> C{Validation Passed?}
    C -->|No| D[Pipeline Fails]
    C -->|Yes| E[Preview Stage]
    E --> F[Deploy Stage]
    F --> G[Post-Deployment Tests]
    G --> H{Tests Passed?}
    H -->|No| I[Mark Deployment as Unhealthy]
    H -->|Yes| J[Deployment Complete]
    
    subgraph "Deploy Stage"
    K[Create Resource Group] --> L[Deploy Bicep Templates] --> M[Extract Outputs]
    end
```

## Authentication & Security

The pipeline uses Azure DevOps service connections for secure authentication to Azure:

- Uses a service principal with appropriate RBAC permissions
- Stores sensitive information in Azure DevOps variable groups or pipeline variables
- Supports approvals and checks before deployment to protected environments

## Setup Instructions

### 1. Configure Azure DevOps Prerequisites

#### Create a Service Connection

1. Navigate to **Project Settings** > **Service connections**
2. Click **New service connection** > **Azure Resource Manager**
3. Select **Service principal (automatic)** or **Service principal (manual)**
4. Fill in the required information and name it `Azure-Service-Connection`
5. Ensure the service principal has Contributor access to your subscription

#### Create Variable Groups (Optional but Recommended)

1. Navigate to **Pipelines** > **Library**
2. Create a variable group named `coffee-app-secrets`
3. Add the following secrets:
   - `sqlAdminUsername`: SQL Server administrator username
   - `sqlAdminPassword`: SQL Server administrator password (mark as secret)

### 2. Configure Environments

1. Navigate to **Pipelines** > **Environments**
2. Create environments for `dev`, `test`, and `prod`
3. For production, add approvals:
   - Navigate to the `prod` environment
   - Click **Approvals and checks** > **Approvals**
   - Add required approvers for production deployments

### 3. Create Pipeline

1. Navigate to **Pipelines** > **Pipelines**
2. Click **New pipeline**
3. Select **Azure Repos Git** or your code source
4. Select your repository
5. Select **Existing Azure Pipelines YAML file**
6. Choose `.azure-pipelines/azure-pipelines.yml` from the repository
7. Click **Continue** and then **Run**

### 4. Customize the Pipeline

You may need to update:

- `projectName` variable in the pipeline to match your project name
- `location` variable to match your preferred Azure region
- Path filters if you reorganize your Bicep files
- Uncomment and configure the variable group reference if you created one

## Usage

### Automatic Deployments

The pipeline automatically runs when:
- Pushing Bicep file changes to the main branch
- Creating a pull request with Bicep file changes
- Weekly on Sunday at midnight (configurable)

### Manual Deployments

To trigger a manual deployment:

1. Navigate to **Pipelines** > **Pipelines**
2. Select the pipeline
3. Click **Run pipeline**
4. Select the environment parameter value
5. Click **Run**

## Pipeline Variables

The pipeline uses the following variables:

| Variable | Description | Default |
|----------|-------------|---------|
| projectName | Name of the project | coffee-ordering |
| location | Azure region for deployment | eastus |
| environment | Target environment (parameter) | dev |

## Monitoring Deployments

Monitor deployments through:
- Azure DevOps Pipeline runs
- Azure DevOps Environments
- Azure Portal > Resource Group > Deployments blade

## Troubleshooting

Common issues and solutions:

1. **Service Connection Issues**: Verify your service principal has valid permissions and the connection is configured correctly.
2. **Secret Management**: Ensure secrets are properly configured in variable groups or pipeline variables.
3. **Deployment Failures**: Check the Azure deployment logs in the pipeline output and Azure Portal.
4. **Parameter Issues**: Ensure all required parameters are provided in the pipeline.

## Resources

- [Azure DevOps Pipelines Documentation](https://docs.microsoft.com/en-us/azure/devops/pipelines/)
- [Azure Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure CLI Documentation](https://learn.microsoft.com/en-us/cli/azure/)