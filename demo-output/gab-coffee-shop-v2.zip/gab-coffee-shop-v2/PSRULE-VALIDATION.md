# PSRule for Azure Infrastructure Validation

This document provides information about validating your Azure Bicep templates against best practices and compliance rules using PSRule for Azure.

## What is PSRule for Azure?

PSRule for Azure is a static analysis tool that scans your infrastructure as code (IaC) templates against predefined rules to ensure compliance with:

- Azure best practices
- Security recommendations
- Performance optimizations
- Cost efficiency guidelines
- Operational excellence standards

## Azure DevOps Pipeline

This project includes a dedicated Azure DevOps pipeline (`ps-rule-pipeline.yml`) for validating Bicep files using PSRule. 

### Pipeline Features

- Automatic validation of Bicep files on PR and main branch pushes
- Weekly scheduled validation
- Publication of validation results as pipeline artifacts
- Configurable rule severity (warning vs. error)

### Setting Up the Pipeline

1. Navigate to **Pipelines** > **Pipelines** in Azure DevOps
2. Click **New pipeline**
3. Select your repository source
4. Choose **Existing Azure Pipelines YAML file**
5. Select `ps-rule-pipeline.yml`
6. Run the pipeline

### PSRule Configuration

Rule configuration is stored in the `.ps-rule` directory:

- `options.ps1`: Contains configuration options for PSRule rules
  - Configure allowed Azure regions
  - Set minimum availability zones
  - Enable/disable specific rules

## Local Validation

You can run PSRule analysis locally on your Windows PC using the included PowerShell script.

### Prerequisites

- Windows PowerShell 5.1 or PowerShell Core 7.x
- Internet connection (for initial module installation)

### Running Local Validation

1. Open PowerShell in administrator mode
2. Navigate to the project directory
3. Run the validation script:

```powershell
# Basic usage - validates all Bicep files and displays results in console
.\Invoke-PSRuleAnalysis.ps1

# Generating an HTML report
.\Invoke-PSRuleAnalysis.ps1 -OutputPath "C:\Reports" -OutputFormat Html

# Validating a specific directory
.\Invoke-PSRuleAnalysis.ps1 -Path "C:\Repos\global-azure-2025\web-app\modules"
```

### Script Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `-As` | Output detail level (`Detail` or `Summary`) | `Detail` |
| `-OutputFormat` | Format of the output (`Yaml`, `Json`, `Markdown`, `NUnit3`, `Csv`, `Sarif`, `Html`) | `Detail` |
| `-OutputPath` | Directory to save output files | None (console only) |
| `-Path` | Directory containing Bicep files to analyze | Current directory |

## Common Rule Categories

PSRule for Azure validates your Bicep templates against several rule categories:

- **Naming and Tagging**: Consistent resource naming and required tags
- **Security**: Network security groups, encryption, RBAC permissions
- **Reliability**: Availability zones, redundancy, backup configurations
- **Performance**: VM sizes, storage account tiers, App Service plan SKUs
- **Cost Optimization**: Reserved instances, auto-shutdown, right-sizing

## Customizing Rules

To customize rule behavior:

1. Edit `.ps-rule/options.ps1` to enable/disable specific rules or adjust rule parameters
2. Add custom rule files to `.ps-rule/` directory as needed

## Troubleshooting

Common issues and solutions:

1. **Module Installation Failures**: 
   - Run PowerShell as administrator
   - Check network connectivity
   - Try `Install-Module PSRule.Rules.Azure -Scope CurrentUser -Force`

2. **Rule Failures**:
   - Review detailed rule output
   - Check [PSRule for Azure documentation](https://azure.github.io/PSRule.Rules.Azure/) for rule details
   - Update your Bicep files to meet requirements or suppress specific rules

## Resources

- [PSRule for Azure Documentation](https://azure.github.io/PSRule.Rules.Azure/)
- [Azure Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure Well-Architected Framework](https://learn.microsoft.com/en-us/azure/architecture/framework/)