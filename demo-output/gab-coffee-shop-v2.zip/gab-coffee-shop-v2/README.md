# Brew Bliss Coffee Ordering Web Application

This repository contains the complete solution for the Brew Bliss Coffee Ordering application, including:
- Web application frontend (HTML, CSS, JS)
- Database schema for customer data and orders
- Infrastructure-as-code (Bicep) templates for Azure deployment
- CI/CD pipelines for automated deployment
- PSRule validation for infrastructure best practices

## Project Overview

Brew Bliss is a coffee ordering web application that allows customers to:
- Create and manage accounts with personal information
- Browse coffee products
- Place orders for coffee delivery
- Track order status
- Update marketing preferences

### Repository Structure

```
/
├── modules/               # Modular Bicep components
│   ├── app-insights.bicep
│   ├── app-service-plan.bicep
│   ├── key-vault.bicep
│   ├── log-analytics.bicep
│   ├── sql.bicep
│   ├── vnet.bicep
│   └── web-app.bicep
├── scripts/               # PowerShell scripts for deployment and management
│   ├── Add-SampleImages.ps1
│   ├── Deploy-WebsiteToAzure.ps1
│   ├── Initialize-Database.ps1
│   ├── Invoke-PSRuleAnalysis.ps1
│   ├── Set-KeyVaultPermissions.ps1
│   └── sql/
│       ├── initialize-schema.sql
│       └── output.log
├── wwwroot/               # Web application files
│   ├── images/            # Coffee product images and icons
│   ├── js/                # JavaScript files
│   ├── index.html         # Main application page
│   └── styles.css         # CSS stylesheets
├── .azure-pipelines/      # Azure DevOps pipeline definitions
│   └── azure-pipelines.yml # Main CI/CD pipeline
├── main.bicep             # Main infrastructure deployment template
├── ps-rule-pipeline.yml   # PSRule validation pipeline
└── various .md files      # Documentation
```

## Getting Started

### Prerequisites

- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli)
- [PowerShell 7+](https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell)
- [Bicep CLI](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/install)
- [SQL CMD](https://learn.microsoft.com/en-us/sql/tools/sqlcmd/sqlcmd-utility) (for database initialization)
- Azure subscription with required permissions

### Local Development

1. Clone the repository:
   ```
   git clone <repository-url>
   cd web-app
   ```

2. Create sample coffee images:
   ```powershell
   .\scripts\Add-SampleImages.ps1
   ```

3. Deploy to Azure:
   ```powershell
   az login
   az deployment group create --resource-group rg-demo-swc01 --template-file main.bicep
   ```

4. Set up Key Vault permissions:
   ```powershell
   .\scripts\Set-KeyVaultPermissions.ps1 -ResourceGroupName "rg-demo-swc01" -KeyVaultName "coffee-ordering-kv-dev"
   ```

5. Initialize the database schema:
   ```powershell
   .\scripts\Initialize-Database.ps1 -ResourceGroupName "rg-demo-swc01" -KeyVaultName "coffee-ordering-kv-dev" -SqlServerName "<your-sql-server-name>" -DatabaseName "<your-database-name>"
   ```

6. Deploy the website to Azure:
   ```powershell
   .\scripts\Deploy-WebsiteToAzure.ps1 -ResourceGroupName "rg-demo-swc01" -WebAppName "<your-web-app-name>"
   ```

## Infrastructure Components

The Azure infrastructure includes:

- **Web App (App Service)**: Hosts the coffee ordering website
- **SQL Database**: Stores customer information and order data
- **Virtual Network**: Secures communication between components
- **Key Vault**: Manages secrets like database credentials
- **Application Insights**: Monitors application performance
- **Log Analytics**: Centralizes logging and monitoring

## Customer Data Schema

The database includes tables for:

- **Customers**: Stores customer information
  - First name, last name
  - Username and email
  - Preferred delivery address
  - Marketing preferences (opt-in/opt-out)
- **Products**: Coffee products and their details
- **Orders**: Customer orders with status and delivery information
- **OrderItems**: Individual items in each order

## PSRule Validation

### Running PSRule Locally

PSRule for Azure helps validate your Bicep templates against Azure best practices before deployment.

```powershell
# Basic usage
.\scripts\Invoke-PSRuleAnalysis.ps1

# Generate HTML report
.\scripts\Invoke-PSRuleAnalysis.ps1 -OutputPath "C:\Reports" -OutputFormat Html

# Validate specific resources
.\scripts\Invoke-PSRuleAnalysis.ps1 -Path ".\modules\web-app.bicep" -OutputFormat Csv
```

Options:
- `-Path`: Specific file(s) to analyze (default: all Bicep files)
- `-OutputFormat`: Report format (Text, Json, Yaml, Markdown, Csv, Html)
- `-OutputPath`: Where to save reports (default: console output)
- `-Baseline`: PSRule baseline to use (default: Azure.All)

### Customizing Rules

You can customize which rules to include/exclude by:

1. Creating a `.ps-rule/options.ps1` file:
   ```powershell
   # Example: Exclude specific rules
   @{
     'rule.exclude' = @(
       'Azure.KeyVault.PurgeProtect'
     )
   }
   ```

2. Setting severity levels:
   ```powershell
   @{
     'rule.severity' = @{
       'Azure.Resource.UseTags' = 'Warning'
     }
   }
   ```

## CI/CD Pipelines

### Azure DevOps Pipeline

The project includes a complete Azure DevOps pipeline for continuous integration and deployment. To use it:

1. Import the repository into Azure DevOps
2. Create a service connection to your Azure subscription
3. Update the variables in `.azure-pipelines/azure-pipelines.yml` if needed
4. Run the pipeline

The pipeline:
- Validates Bicep templates with PSRule
- Deploys infrastructure to Azure
- Deploys the web application
- Initializes the database schema

### PSRule Validation Pipeline

A dedicated PSRule validation pipeline (`ps-rule-pipeline.yml`) runs PSRule checks on your Bicep templates:

```mermaid
flowchart TD
    A[Trigger: Push/PR/Schedule/Manual] --> B[Checkout Code]
    B --> C[Install PSRule Modules]
    C --> D[Run PSRule Analysis]
    D --> E{Any Rule Violations?}
    E -->|Yes| F[Generate Violation Report]
    E -->|No| G[All Rules Passed]
    F --> H[Upload Results as Artifacts]
    G --> H
    H --> I[Publish Test Results]
```

To run a manual validation:
1. Go to Pipelines in Azure DevOps
2. Select the PSRule pipeline
3. Run with parameters for custom output format or specific files

## Troubleshooting

### Key Vault Access

If you encounter permissions issues with Key Vault:

```powershell
.\scripts\Set-KeyVaultPermissions.ps1 -ResourceGroupName "rg-demo-swc01" -KeyVaultName "coffee-ordering-kv-dev"
```

### Database Connectivity

If you have issues connecting to the SQL database:

1. Verify your IP is allowed in the SQL Server firewall
2. Check Key Vault for correct connection strings
3. Validate network security group settings

## Resources

- [Azure Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [PSRule for Azure Documentation](https://azure.github.io/PSRule.Rules.Azure/)
- [Azure Well-Architected Framework](https://learn.microsoft.com/en-us/azure/architecture/framework/)
- [SQL Server Management Best Practices](https://learn.microsoft.com/en-us/sql/relational-databases/security/securing-sql-server)